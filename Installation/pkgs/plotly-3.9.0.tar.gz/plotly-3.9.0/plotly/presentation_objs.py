from __future__ import absolute_import

from _plotly_future_ import _chart_studio_warning
_chart_studio_warning('presentation_objs')
from chart_studio.presentation_objs import *
