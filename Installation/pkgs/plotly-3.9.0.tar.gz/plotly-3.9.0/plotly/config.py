from __future__ import absolute_import

from _plotly_future_ import _chart_studio_warning
_chart_studio_warning('config')
from chart_studio.config import *
