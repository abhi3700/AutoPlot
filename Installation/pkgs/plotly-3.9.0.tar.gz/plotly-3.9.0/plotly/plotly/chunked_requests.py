from __future__ import absolute_import

from _plotly_future_ import _chart_studio_warning
_chart_studio_warning('plotly.chunked_requests')
from chart_studio.plotly.chunked_requests import *
